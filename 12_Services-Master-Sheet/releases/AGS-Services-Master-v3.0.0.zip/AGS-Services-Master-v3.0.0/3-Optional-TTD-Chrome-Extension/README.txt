Only for PCs where you book on the TTD website. Not needed for other services.
Unzip to a permanent folder, then Chrome > chrome://extensions > Developer mode > Load unpacked.
Connect it: dashboard Settings > Create API key; extension Options > Google Sheet tab. (Guide section 5.)
