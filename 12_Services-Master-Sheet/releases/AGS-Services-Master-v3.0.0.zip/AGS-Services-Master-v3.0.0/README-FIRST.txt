AGS SERVICES MASTER v3.0.0  -  Adithya Group of Services
CRM for TTD, Train/Bus/Flight, Aadhaar, PAN, Voter ID, Certificates and all CSC services.

START HERE
  1. Open  AGS-Services-Master-Guide.pdf  (key features, install steps with pictures, daily use, Telugu summary).
  2. Want to look around first?  Open  2-Try-the-demo  in Chrome. Login: Admin / 1234 (made-up data).
  3. Install (one time, ~20 min): follow guide section 3 using the 5 files in  1-Install.
     In Apps Script the files are named  Code, Index, Styles, App  (the numbers only show the order).
  4. Optional: 3-Optional-TTD-Chrome-Extension  only for PCs where you book on the TTD website.

Everything is free. Your data stays in your own Google Sheet.
